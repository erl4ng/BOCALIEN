echo "ibase=?!;obase=gtaio luSnemf;FT_NBR1" | bc | tr '0123456789ABCDEF' '0123456789ghijklmop'
