find . -type d -o -type f | grep -c -e "/$" -e ""
